import { useEffect, useState } from "react"


function App() {
  const {count, setCount} = useState(0)
  const {name, setName} = useState("")

  useEffect(()=> {
    console.log("Use effet no modo de execução")
    console.log("Executa a cada rederização !")
  })
  
  useEffect(()=> {
    console.log("Executa somente a primeira vez")
  }, [])


  useEffect(()=> {
    console.log("Monitorando mudança de estado")
  }, [count])


}

 